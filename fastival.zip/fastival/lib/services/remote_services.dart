import 'dart:convert';
import 'package:http/http.dart' as http;
import '../model/category_model.dart';

Future<List<CategoryModel>?> getCategory() async {
  final response = await http.get(
    Uri.parse("https://jsonplaceholder.typicode.com/posts"),
  );
  if (response.statusCode == 200) {
    List jsonData = jsonDecode(response.body);
    return jsonData.map((e) => CategoryModel.fromJson(e)).toList();
  }
  return null;
}
